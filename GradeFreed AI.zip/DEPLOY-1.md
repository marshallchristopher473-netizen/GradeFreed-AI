# GradeFreed AI — Vercel Deployment Guide
## Zero to live in under 20 minutes

---

## What You're Doing and Why

Right now your app calls the Anthropic API directly from the browser.
That means your API key is visible to anyone who opens Chrome DevTools.
This is a security problem and a billing risk.

After following this guide:
- Your API key lives only on Vercel's servers (never in the browser)
- Your app is live on a public URL (free)
- Total cost: $0

---

## Files Added to Your Project

```
your-project/
├── api/
│   └── claude.js          ← NEW: secure server that holds your API key
├── src/
│   └── App.jsx            ← CHANGE: one function swap (callAI)
├── .env.example           ← NEW: template showing what keys are needed
├── .env.local             ← NEW (you create this): your actual secret key
├── .gitignore             ← NEW/UPDATED: keeps .env.local off GitHub
├── vercel.json            ← NEW: tells Vercel how to build and route the app
└── vite.config.js         ← UPDATED: adds local dev proxy
```

---

## Step 1 — Install dependencies (if not already done)

Open your terminal in the project folder and run:

```bash
npm install
```

If you get a "vite not found" error, also run:

```bash
npm install --save-dev vite @vitejs/plugin-react
```

---

## Step 2 — Make the one change to App.jsx

Open `src/App.jsx` in your code editor.

Search for this exact text (Ctrl+F / Cmd+F):
```
https://api.anthropic.com/v1/messages
```

You will find it inside the `callAI` function near the top of the file.

**Delete the entire `callAI` function** (it is about 10 lines long).

**Paste this in its place:**

```javascript
const callAI = async (prompt) => {
  const res = await fetch('/api/claude', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt }),
  });
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || `Server error — HTTP ${res.status}`);
  }
  const d = await res.json();
  if (d.error) throw new Error(d.error);
  return d.text ?? 'No response received.';
};
```

Save the file. That is the only change to App.jsx.

---

## Step 3 — Create your local .env.local file

1. Copy the example file:
   ```bash
   cp .env.example .env.local
   ```

2. Open `.env.local` in your editor. It looks like this:
   ```
   ANTHROPIC_API_KEY=your_anthropic_api_key_here
   ```

3. Get your real API key:
   - Go to https://console.anthropic.com/settings/keys
   - Click **Create Key**
   - Copy the key (it starts with `sk-ant-api03-...`)

4. Replace `your_anthropic_api_key_here` with your real key:
   ```
   ANTHROPIC_API_KEY=sk-ant-api03-abc123...
   ```

5. Save `.env.local`. **Never share this file or commit it to GitHub.**
   It is already in `.gitignore` so Git will ignore it automatically.

---

## Step 4 — Push your project to GitHub

If your project is not on GitHub yet:

```bash
# Initialize a git repo
git init

# Stage all files
git add .

# First commit
git commit -m "Initial commit — GradeFreed AI"
```

Then:
1. Go to https://github.com/new
2. Create a new repository called `gradefreed-ai`
3. Copy the commands GitHub shows you (the "push an existing repository" section)
4. Paste and run them in your terminal

If your project is already on GitHub:
```bash
git add .
git commit -m "Add Vercel serverless function and deployment config"
git push
```

---

## Step 5 — Deploy to Vercel

1. Go to https://vercel.com and sign in (free account)

2. Click **Add New → Project**

3. Click **Import** next to your `gradefreed-ai` repository

4. Vercel will auto-detect Vite. Leave all settings as-is.

5. Before clicking Deploy, click **Environment Variables**

6. Add your API key:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** paste your key from Step 3 (sk-ant-api03-...)
   - Click **Add**

7. Click **Deploy**

8. Wait ~60 seconds. Vercel will give you a URL like:
   `https://gradefreed-ai.vercel.app`

That URL is your live app.

---

## Step 6 — Verify it works

1. Open your Vercel URL in a browser
2. Go to **AI Grader**
3. Paste any student text and click **Grade This Paper**
4. If you see a grade result → it works ✅
5. If you see an error → check Step 7 below

---

## Step 7 — Troubleshooting

**Error: "ANTHROPIC_API_KEY is not set"**
→ Go to Vercel dashboard → your project → Settings → Environment Variables
→ Make sure ANTHROPIC_API_KEY is there
→ Go to Deployments → click the three dots → Redeploy

**Error: "HTTP 401" or "Invalid API key"**
→ Your key is wrong or expired
→ Go to https://console.anthropic.com/settings/keys and create a new one
→ Update it in Vercel Environment Variables and redeploy

**Error: "HTTP 529" or "Overloaded"**
→ Anthropic is temporarily busy. Try again in 30 seconds.

**White screen or "Page not found" on Vercel**
→ Make sure `vercel.json` is in the ROOT of your project (not inside /src)
→ Make sure `vite.config.js` is also in the root

**AI works on Vercel but not locally**
→ That is expected if you run `npm run dev`
→ For local testing with the API, install Vercel CLI and run `vercel dev`:
```bash
npm install -g vercel
vercel login
vercel dev
```
Then open http://localhost:3000

---

## Step 8 — Every future update

After you make changes to your code:
```bash
git add .
git commit -m "describe what you changed"
git push
```

Vercel automatically redeploys every time you push to GitHub.
No manual steps needed after the first deploy.

---

## Security Checklist Before Going Public

- [ ] `.env.local` is in `.gitignore` ✅ (already done)
- [ ] `ANTHROPIC_API_KEY` is in Vercel environment variables, not in code
- [ ] You searched your App.jsx for `api.anthropic.com` and it no longer appears
- [ ] You searched your App.jsx for `x-api-key` and it no longer appears
- [ ] `api/claude.js` is the ONLY place your API key is used

---

## Your Free Tier Limits on Vercel

| What | Free Limit |
|---|---|
| Deployments | Unlimited |
| Serverless function calls | 100,000/month |
| Bandwidth | 100 GB/month |
| Custom domain | 1 free domain |

GradeFreed AI at typical teacher usage will stay well within free limits
until you hit ~10,000 active monthly users.

---

*GradeFreed AI — Score Higher Education*
