// ─────────────────────────────────────────────────────────────
// api/_shared/anthropic.js
//
// One place that actually talks to Anthropic. Both /api/claude
// and /api/grade import this, so the timeout, headers, and
// error-shape logic only exist once instead of being copy-pasted.
//
// TIMEOUT NOTE: Vercel's Hobby (free) plan lets a serverless
// function run for up to 60 seconds if you set maxDuration in
// vercel.json / the function's config export — the platform
// default without that config is much shorter (single-digit
// seconds), so we set maxDuration explicitly below AND abort
// our own fetch at 25s so we always return a clean error to the
// browser instead of letting Vercel kill the function cold.
// ─────────────────────────────────────────────────────────────

export async function callAnthropic({ apiKey, maxTokens = 1200, messages }) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 25_000);

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: maxTokens,
        messages,
      }),
      signal: controller.signal,
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      const err = new Error(errData?.error?.message || `Anthropic API error — status ${res.status}`);
      err.status = res.status;
      throw err;
    }

    const data = await res.json();
    return data.content?.[0]?.text ?? '';

  } catch (e) {
    if (e.name === 'AbortError') {
      const err = new Error('The AI service took too long to respond (25s timeout). Please try again.');
      err.status = 504;
      throw err;
    }
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

// Claude sometimes wraps JSON in ```json fences despite instructions
// not to. This strips them before JSON.parse, and throws a clear
// error (instead of a cryptic parse crash) if the result still isn't
// valid JSON matching the expected shape.
export function parseStructuredJSON(text, requiredKeys = []) {
  const cleaned = text.replace(/```json|```/g, '').trim();
  let parsed;
  try {
    parsed = JSON.parse(cleaned);
  } catch {
    const err = new Error('AI response was not valid JSON. This usually means the AI misunderstood the request — try again.');
    err.status = 502;
    throw err;
  }
  const missing = requiredKeys.filter(k => !(k in parsed));
  if (missing.length) {
    const err = new Error(`AI response was missing required field(s): ${missing.join(', ')}. Try again.`);
    err.status = 502;
    throw err;
  }
  return parsed;
}
